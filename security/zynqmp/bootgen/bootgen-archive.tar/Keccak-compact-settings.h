#define cKeccakB    1600
#define cKeccakR    832
#define cKeccakFixedOutputLengthInBytes 48
